#Enviar mensaje
def mensaje():
    print("Estudio Ingenieria en sistemas de informacion UAM")

#Principal
mensaje()