#Ejemplificando funciones en python
#Definiendo la funcion suma
def suma():
    n1=int(input("Ingrese un numero:"))
    n2=int(input("Ingrese otro nunmero:"))
    resultado=n1+n2
    return resultado

#Principal
print("Programa usando funciones en Python")

#resp=suma()
print("La suma es:", suma())